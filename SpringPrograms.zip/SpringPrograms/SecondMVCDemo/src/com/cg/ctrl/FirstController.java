package com.cg.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class FirstController {
	
	@Autowired
	Login login;
	
	@RequestMapping(value="/login")
	public String login(Model m) {
		m.addAttribute("login",login);
		return "login";
	
	}	
    @RequestMapping
	public String checklogin(Login lin){
		if(lin.getUsername().equals("admin")&&lin.getPassword().equals("1234"))
		{
			return "success";
		}
		
		
			return "login";
		}
	}
	

