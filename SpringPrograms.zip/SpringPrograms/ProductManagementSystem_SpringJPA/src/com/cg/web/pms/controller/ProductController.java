package com.cg.web.pms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.web.pms.entities.Product;
import com.cg.web.pms.exception.PMSException;
import com.cg.web.pms.service.ProductService;


@Controller
public class ProductController {
	@Autowired
	private ProductService productService;

	public ProductService getProductService() {
		return productService;
	}

	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	@RequestMapping(value="/Home.mvc")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	@RequestMapping(value="/addproduct.mvc",method=RequestMethod.GET)
	public String getAddProductPage(Model model)
	{
		
		model.addAttribute("product",new Product());
		return "AddProduct";
	}
	@RequestMapping(value="processAddProduct.mvc",method=RequestMethod.POST)
	public String processAddProductForm(
			@ModelAttribute("product") @Valid Product product, 
			Model model,
			BindingResult result)
	{
		if(result.hasErrors()==true)
		{
			return "AddProduct";
		}
		
		try
		{
			int productId=productService.addProduct(product);
			
			model.addAttribute("msg","Product added successfull.Product Id:"+productId);
			model.addAttribute("product",new Product());
			return "AddProduct";
		}
		catch(PMSException e){
			e.printStackTrace();
			model.addAttribute("errMsg","Something went wrong:Error:"+e.getMessage());
			return "ErrorPage";
		}
	}
		@RequestMapping(value="/ViewAllProducts.html", method=RequestMethod.GET)
		public String getViewAllProductsPage(Model model)
		{
			try
			{
				List<Product> products=productService.viewAllProducts();
				
				model.addAttribute("products",products);
				return "ViewAllProducts";
			}
			catch(PMSException e)
			{
				e.printStackTrace();
				model.addAttribute("errMsg","Something went wrong: Error:" +e.getMessage());
				return "ErrorPage";
			}
		}
		
	}


