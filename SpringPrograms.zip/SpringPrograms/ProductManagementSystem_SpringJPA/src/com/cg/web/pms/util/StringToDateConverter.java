package com.cg.web.pms.util;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringToDateConverter extends PropertyEditorSupport{

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
		try {
			
			
			Date date=formatter.parse(text);
			setValue(date);
			
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
	}
	
	@Override
	public String getAsText() {
		
		return getValue().toString();
		
	}
}
