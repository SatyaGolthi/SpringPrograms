package com.cg.web.pms.service;

import java.util.List;

import com.cg.web.pms.entities.Product;
import com.cg.web.pms.exception.PMSException;

public interface ProductService {
	
public int addProduct(Product product) throws PMSException;
	
	public Product getProduct(int productId)  throws PMSException;
	
	public void updateProduct(Product pro)  throws PMSException; 
	
	public void removeProduct(int productId)  throws PMSException;
	
	public List<Product> viewAllProducts()  throws PMSException;


}
