package com.cg.web.pms.dao;

import java.util.List;




import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.web.pms.entities.Product;
import com.cg.web.pms.exception.PMSException;

@Repository
public class ProductDAOImpl implements ProductDAO {
	
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int addProduct(Product product) throws PMSException {
		int productId=0;
		
		try {
			entityManager.persist(product); //id gets assigned to product bean
			
			productId=product.getId();
		} catch (Exception e) {
			
			e.printStackTrace();
			throw new PMSException(e.getMessage());
		}
		return productId;
	}

	@Override
	public Product getProduct(int productId) throws PMSException {
		
		Product product=null;
		
		try {
			product=entityManager.find(Product.class, productId);
			
			if(product==null)
				throw new Exception("No Product with id" +productId);
		} catch (Exception e) {
		
			e.printStackTrace();
			throw new PMSException(e.getMessage());
		}
		
		return product;
	}

	@Override
	public void updateProduct(Product product) throws PMSException {
		try {
			entityManager.merge(product);
			
		} catch (Exception e) {
			
			e.printStackTrace();
			throw new PMSException(e.getMessage());
		}

	}

	@Override
	public void removeProduct(int productId) throws PMSException {

		Product product=null;
		
		try {
			product=getProduct(productId);
			entityManager.remove(new Product(productId));
			
			
		} catch (Exception e) {
		
			e.printStackTrace();
			throw new PMSException(e.getMessage());
		}
		
	
	}

	@Override
	public List<Product> viewAllProducts() throws PMSException {
		List<Product> products=null;
		try {
			
			TypedQuery<Product> query=entityManager.createNamedQuery("GetAllProducts",Product.class);
			
			products=query.getResultList();
			
			if(products==null||products.isEmpty())
				throw new PMSException("No products to display");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PMSException(e.getMessage());
		}
		
		
		return products;
	}

}
