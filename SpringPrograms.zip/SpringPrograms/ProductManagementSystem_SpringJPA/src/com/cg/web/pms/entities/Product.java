package com.cg.web.pms.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

//POJO => Bean =>JavaBean =>EnterpriseJavaBean

//JavaBean

@Entity
@NamedQueries(
		value={@NamedQuery(
				name="GetAllProducts",
				       query="from Product product")})
public class Product implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private String name;
	private double price;
	private int quantity; 
	
	@Temporal(TemporalType.DATE)
	private Date dateOfManufacturing;
	
	
	public Product() {
    }
	
	
	public Product(int id, String name, double price, int quantity,
			Date dateOfManufacturing) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.dateOfManufacturing = dateOfManufacturing;
	}
	
	public Product(int id){
		super();
		this.id=id;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getDateOfManufacturing() {
		return dateOfManufacturing;
	}
	public void setDateOfManufacturing(Date dateOfManufacturing) {
		this.dateOfManufacturing = dateOfManufacturing;
	}
	

}
