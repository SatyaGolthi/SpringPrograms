package com.cg.web.pms.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.web.pms.dao.ProductDAO;
import com.cg.web.pms.entities.Product;
import com.cg.web.pms.exception.PMSException;


@Service
@Transactional //enables spring server transaction on all service methods

public class ProductServiceImpl implements ProductService {

	private ProductDAO productDAO;
	
	public ProductDAO getProductDAO() {
		return productDAO;
	}

	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	
	
	@Override
	public int addProduct(Product product) throws PMSException {
	
		return productDAO.addProduct(product);
	}

	@Override
	public Product getProduct(int productId) throws PMSException {
	
		return productDAO.getProduct(productId);
	}

	@Override
	public void updateProduct(Product pro) throws PMSException {
		productDAO.updateProduct(pro);

	}

	@Override
	public void removeProduct(int productId) throws PMSException {
	    productDAO.removeProduct(productId);

	}

	@Override
	public List<Product> viewAllProducts() throws PMSException {
	
		return productDAO.viewAllProducts();
	}

}
