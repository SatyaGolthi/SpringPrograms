package com.cl;

import java.util.ArrayList;

public class CurrentListImpl implements CurrencyList{

	
	
		private ArrayList<String> currList;

		@Override
		public ArrayList<String> getCurrList() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}
	


