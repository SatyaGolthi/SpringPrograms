package com.user;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("use.xml");
		User user=(User)ctx.getBean("user");
		System.out.println(user.getUsername());
		System.out.println(user.getPassword());

		
	}
}
