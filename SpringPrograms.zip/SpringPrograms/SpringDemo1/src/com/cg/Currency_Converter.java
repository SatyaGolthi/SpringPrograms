package com.cg;

public interface Currency_Converter {
	public double dollarsToRupees(double dollars);
}
