package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Currency implements Currency_Converter,InitializingBean,BeanNameAware,BeanFactoryAware {
	private ExchangeService exchangeService;
	
	
	
/*public double getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	@Override
	public double dollarsToRupees(double dollars) {
		System.out.println("dollarsToRuppes");
		return exchangeRate;
	}
*/

@Override
public void setBeanFactory(BeanFactory arg0) throws BeansException {
	// TODO Auto-generated method stub
	
}


@Override
public void setBeanName(String arg0) {
	// TODO Auto-generated method stub
	
}


@Override
public void afterPropertiesSet() throws Exception {
	// TODO Auto-generated method stub
	
}

/*public Currency(double exchangeRate){
	System.out.println("CurrencyConverterImpl()");
	this.exchangeRate=exchangeRate;
}

public Currency(String exchangeRate){
	System.out.println("CurrencyConverterImpl()" +"stringparameter");
	this.exchangeRate=Double.parseDouble(exchangeRate);
}
*/

@Override
public double dollarsToRupees(double dollars) {
	// TODO Auto-generated method stub
	return dollars;
}
}

