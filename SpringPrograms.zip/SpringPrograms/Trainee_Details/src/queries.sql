create table Trainer(Trainee_Id number primary key,Trainee_name varchar2(10),Trainee_loc varchar2(20),Trainee_dom varchar2(20));

create sequence trainee_Id start with 100;