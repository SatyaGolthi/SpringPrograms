package com.cg.web.tms.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.web.tms.dao.TrainerDao;
import com.cg.web.tms.entities.Trainer;
import com.cg.web.tms.exception.TrainerException;

@Service
@Transactional //all methods are in transaction managed by container
public class TrainerServiceImpl implements TrainerService {

	private TrainerDao dao;
	
	public TrainerDao getTrainerdao() {
		return dao;
	}

	public void setTrainerdao(TrainerDao trainerdao) {
		this.dao = dao;
	}

	@Override
	public Trainer addTrainer(Trainer trainer) throws TrainerException {
		// TODO Auto-generated method stub
		return dao.addTrainer(trainer);
	}

	@Override
	public Trainer getTrainer(int Trainee_Id) throws TrainerException {
		// TODO Auto-generated method stub
		return null;
	}

}
