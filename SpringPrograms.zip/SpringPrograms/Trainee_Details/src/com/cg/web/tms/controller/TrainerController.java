package com.cg.web.tms.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cg.web.tms.entities.Trainer;
import com.cg.web.tms.exception.TrainerException;
import com.cg.web.tms.service.TrainerService;


@Controller
public class TrainerController {
	
	@Autowired
	private TrainerService trainerService;

	public TrainerService getTrainerService() {
		return trainerService;
	}

	public void setTrainerService(TrainerService trainerService) {
		this.trainerService = trainerService;
	}


	@RequestMapping(value="/goToMenu", method=RequestMethod.GET)
	public String getMenuPage()
	{
		return "Menu";
	}
	
	public List<String> getCategoryList()
	{
		List<String> categories = new ArrayList<String>();
		
		categories.addAll( 
				Arrays.asList("Chennai", "Bangalore", "Pune", "Mumbai"));
		
		return categories;
	}
	

	@RequestMapping(value="/addTrainee.html", method=RequestMethod.POST)
	public String processAddTrainerForm(
			@ModelAttribute("trainer") @Valid Trainer trainer,
			BindingResult formValidationResult, 
			Model model)
	{
		if( formValidationResult.hasErrors() )
		{
			model.addAttribute("categoryList", getCategoryList());
			
			return "AddTrainee";
		}
		
		try 
		{
			trainer = trainerService.addTrainer( trainer );
			
			model.addAttribute("info", " Details of " + trainer.getTrainee_name() + " added successfully with "
					+ "Trainer ID " + trainer.getTrainee_Id() );
			
			model.addAttribute("categoryList", getCategoryList());			
			model.addAttribute("Trainer", new Trainer());
			
			return "AddTrainee";
		}
		catch (TrainerException e) 
		{
			model.addAttribute("errMsg", "Something went wrong while trying "
					+ "to add Trainee Details. Reason: " + e.getMessage() );
			
			return "ErrorPage";
		}
	}
	
}
