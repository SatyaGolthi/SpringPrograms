package com.cg.web.tms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.web.tms.entities.Trainer;
import com.cg.web.tms.exception.TrainerException;

@Repository
public class TrainerDaoImpl implements TrainerDao {
	
	@PersistenceContext
	 EntityManager entityManager;

    @Transactional
	@Override
	public Trainer addTrainer(Trainer trainer) throws TrainerException {
		try 
		{
			entityManager.persist( trainer );
			entityManager.flush();
		} 
		catch (Exception e) 
		{
			throw new TrainerException( e.getMessage() );
		}
		
		return trainer;
	}
	

	@Override
	public Trainer getTrainer(int Trainee_Id) throws TrainerException {
		// TODO Auto-generated method stub
		return null;
	}

}
