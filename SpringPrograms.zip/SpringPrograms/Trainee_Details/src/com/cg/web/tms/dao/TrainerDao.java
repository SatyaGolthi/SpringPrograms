package com.cg.web.tms.dao;


import com.cg.web.tms.entities.Trainer;
import com.cg.web.tms.exception.TrainerException;

public interface TrainerDao {
	
public Trainer addTrainer( Trainer trainer ) throws TrainerException;
	
	public Trainer getTrainer( int Trainee_Id ) throws TrainerException;
	

}
