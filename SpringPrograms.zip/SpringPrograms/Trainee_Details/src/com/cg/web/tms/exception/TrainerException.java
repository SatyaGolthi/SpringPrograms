package com.cg.web.tms.exception;

public class TrainerException extends Exception{

	public TrainerException() {
		super();
		
	}

	public TrainerException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);

	}

	public TrainerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public TrainerException(String arg0) {
		super(arg0);
		
	}

	public TrainerException(Throwable arg0) {
		super(arg0);
		
	}

}
