package com.cg.web.tms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Trainer")

public class Trainer {
    
	
	
	
	@SequenceGenerator(name="train",sequenceName="trainee_Id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="train")
	@Id
	private int Trainee_Id;
	
	@Column(name="Trainee_name")
	@NotEmpty
	private String Trainee_name;
	private String Trainee_loc;
	private String Trainee_dom;
	
	
	public int getTrainee_Id() {
		return Trainee_Id;
	}
	public void setTrainee_Id(int trainee_Id) {
		Trainee_Id = trainee_Id;
	}
	public String getTrainee_name() {
		return Trainee_name;
	}
	public void setTrainee_name(String trainee_name) {
		Trainee_name = trainee_name;
	}
	public String getTrainee_loc() {
		return Trainee_loc;
	}
	public void setTrainee_loc(String trainee_loc) {
		Trainee_loc = trainee_loc;
	}
	public String getTrainee_dom() {
		return Trainee_dom;
	}
	public void setTrainee_dom(String trainee_dom) {
		Trainee_dom = trainee_dom;
	}
	
	/*public Trainer(int trainee_Id, String trainee_name, String trainee_loc,
			String trainee_dom) {
		super();
		Trainee_Id = trainee_Id;
		Trainee_name = trainee_name;
		Trainee_loc = trainee_loc;
		Trainee_dom = trainee_dom;
	}*/
	
	
	public Trainer(String trainee_name, String trainee_loc, String trainee_dom) {
		super();
		Trainee_name = trainee_name;
		Trainee_loc = trainee_loc;
		Trainee_dom = trainee_dom;
	}
	/*@Override
	public String toString() {
		return "Trainer [Trainee_Id=" + Trainee_Id + ", Trainee_name="
				+ Trainee_name + ", Trainee_loc=" + Trainee_loc
				+ ", Trainee_dom=" + Trainee_dom + "]";
	}
	*/
	public Trainer() {
		// TODO Auto-generated constructor stub
	}
	
}
