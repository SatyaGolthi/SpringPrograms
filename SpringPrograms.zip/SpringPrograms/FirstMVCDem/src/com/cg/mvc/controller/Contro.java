package com.cg.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Contro {

	
	@RequestMapping("/servlet1")
	public String login(@RequestParam("uname")String userName,@RequestParam("pswrd")String password,Model m) {
		m.addAttribute("uname",userName);
		return "success";
		
	}

}
