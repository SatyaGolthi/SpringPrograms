package com.cg.ctrl;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class User {
	@NotEmpty(message="please enter the first name")
	@Size(min=4,max=10)
	@Pattern(regexp="Satya")
	private String firstname;
	@NotEmpty(message="please enter the lastname")
	private String lastname;
	@Email(message="please enter the valid emailId")
	private String eMail;
	private char gender;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String[] getSkillset() {
		return skillset;
	}
	public void setSkillset(String[] skillset) {
		this.skillset = skillset;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	private String[] skillset;
    private String city;
}
