package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class MyController {
	
	@Autowired
	Login login;
	
	@RequestMapping(value="/login")
	public String login(Model m) {
		m.addAttribute("login",login);
		return "login";
		
	}
	
	@RequestMapping(value="/checklogin")
	public String checkLogin(Login lin) {
		if(lin.getUsername().equals("satya")&&lin.getPassword().equals("123"))
		{
			return "success";
		}
		else 
		
		return "login";
	}
	
	@RequestMapping(value="/register")
	public String register(Model model){
		model.addAttribute("register",new User());
		return "register";
	}	
		
	@RequestMapping(value="/checkRegister")
	public String checkRegister(User user,Model model)
	{
		model.addAttribute("user",user);
		return "registersuccess";
		
	}
	
	@RequestMapping(value="/showRegister")
	public String prepareRegister(Model model)
	{
		cityList=new ArrayList<String>();
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		
		skillList=new ArrayList<String>();
		
		skillList.add("Java");
		skillList.add("Struts");
		
		model.addAttribute("cityList",cityList);
		model.addAttribute("skillList",skillList);
		
		model.s
		
		
		
		
	}
	
	checkregister(@Valid @ModelAttribute("register") Register register,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			
			model.addAttribute("cityList",cityList);
			add skillset("skillList",skillList);
			return "register";
		}
		else
		{
			//remaining old code
			return "success";
		}
	}
			
	
	
		
	}

