package com.cg.ma.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ma.dto.Mobile;

/**
 * Servlet implementation class showAllMobileView
 */
@WebServlet("/showAllMobiles")
public class showAllMobileView extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Mobile> mlist =(List<Mobile>)request.getAttribute("mlist");
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		for(Mobile m:mlist){
			out.print("<h2>");
			out.print(m.getMobileid()+"--");
			out.print(m.getMname()+"--");
            out.print(m.getPrice()+"--");
            out.print(m.getQuantity()+"--");
            out.print("</h2>");
		}
		out.print("<a href='index.html'>Home</a>");

}
}
