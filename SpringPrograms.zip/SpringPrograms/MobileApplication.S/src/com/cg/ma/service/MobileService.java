package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;



public interface MobileService {
	List<Mobile> getAllMobiles() throws MobileException;
	Mobile searchMobile(int mid)throws MobileException;
	int insertMobile(Mobile mobile)throws MobileException;

}
