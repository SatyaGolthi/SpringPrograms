package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dao.MobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;

public class MobileServiceImpl implements MobileService {
	MobileDao mdao = new MobileDaoImpl();
	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
	return mdao.getAllMobiles()	;
	}
	@Override
	public Mobile searchMobile(int mid) throws MobileException {
	 return mdao.searchMobile(mid)	;
	}
	@Override
	public int insertMobile(Mobile h) throws MobileException {
		return mdao.insertMobile(h);
	}
}
	
