package com.cg.ma.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;
import com.cg.ma.service.MobileService;
import com.cg.ma.service.MobileServiceImpl;

/**
 * Servlet implementation class MobileController
 */
@WebServlet(urlPatterns={"/insert" ,"/search","/showAll"})
public class MobileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		MobileService mser = new MobileServiceImpl();
		String targeturl="";
		String url = request.getServletPath();
		switch(url) {
		case "/insert" :
		
		String mname= request.getParameter("mname");
		double price = Double.parseDouble(request.getParameter("price"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		
		Mobile mobile = new Mobile();
		mobile.setMname(mname);
		mobile.setPrice(price);
		mobile.setQuantity(quantity);
		
		//System.out.println(url);
	
		try{
			int mid = mser.insertMobile(mobile);
			
			request.setAttribute("mid" , mid);
		    targeturl = "success";
		}
		catch(Exception e){
			e.printStackTrace();
			request.setAttribute("message",e.getMessage());
			targeturl = "error";
		}
		break;
		   
		case "/search" :
				 int mid = Integer.parseInt(request.getParameter("mid"));
				try {
					Mobile m=mser.searchMobile(mid);
					request.setAttribute("mobile", m);
					targeturl="showMobile";
					
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("message", e.getMessage());
					targeturl="error";
				}
		       break;
		       
		       
		case "/showAll" :
			try {
				List<Mobile> mlist = mser.getAllMobiles();
				request.setAttribute("mlist",mlist);
				targeturl="showAllMobiles";
			} catch (MobileException e) {
				e.printStackTrace();
				request.setAttribute("message", e.getMessage());
				targeturl="error";
				
			}
			
			}
		   RequestDispatcher disp=request.getRequestDispatcher(targeturl);
		   disp.forward(request,response);
		
		}
}