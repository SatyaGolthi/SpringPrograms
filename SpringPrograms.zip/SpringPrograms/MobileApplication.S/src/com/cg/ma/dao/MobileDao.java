package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;

public interface MobileDao {

	  int insertMobile(Mobile mobile)throws MobileException;
	  List<Mobile> getAllMobiles() throws MobileException;
	  Mobile searchMobile(int mid)throws MobileException;
}
