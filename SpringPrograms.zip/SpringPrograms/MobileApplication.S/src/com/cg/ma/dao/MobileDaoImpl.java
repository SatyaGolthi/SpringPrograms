package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;

public class MobileDaoImpl implements MobileDao {
	Connection conn;

	@Override
	public int insertMobile(Mobile mobile) throws MobileException {
		mobile.setMobileid(generateMobileid());
		String sql = "INSERT INTO Mobiles1 values(?,?,?,?)";
		conn = DBUtil.getConnection();
		try{
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setInt(1,mobile.getMobileid());
		pst.setString(2, mobile.getMname());
		pst.setDouble(3,mobile.getPrice());
		pst.setInt(4, mobile.getQuantity());
		pst.executeUpdate();
	}catch(SQLException e){
		throw new MobileException("problem in inserting mobile details" +e.getMessage());
	}
				return mobile.getMobileid();
	}
	
	
    private int generateMobileid() throws MobileException{
    	String sql = "SELECT seq_mobile_id.NEXTVAL FROM dual";
    	conn = DBUtil.getConnection();
int Id=0;
    	try{
    	Statement st=conn.createStatement();
		ResultSet rst=st.executeQuery(sql);
		while(rst.next()) {
		Id= rst.getInt(1); }
    }catch(SQLException e){
    	throw new MobileException("problem in generating mobile id"+e.getMessage());
    }
    	return Id;
    }
		
    	
    
	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		String sql= "SELECT mobileid, name,price,quantity FROM Mobiles1";
				List<Mobile> mlist = new ArrayList<Mobile>();
		conn = DBUtil.getConnection();
		try{
		
		Statement st=conn.createStatement();
		ResultSet rst = st.executeQuery(sql);
		while(rst.next())
		{
			Mobile m=new Mobile();
			m.setMname(rst.getString("name"));
			m.setMobileid(rst.getInt("mobileid"));
			m.setPrice(rst.getDouble("price"));
			m.setQuantity(rst.getInt("quantity"));
			mlist.add(m);
		}
		}catch(SQLException e){
			throw new MobileException("problem in getting mobile list"+e.getMessage());
		}
		return mlist;
	}

	
	@Override
	public Mobile searchMobile(int mid) throws MobileException {
		String sql= "select mobileid,name,price,quantity FROM Mobiles1"
				+" WHERE mobileid=?";
		Mobile m=null;
		conn = DBUtil.getConnection();
		try{
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, mid);

			ResultSet rst = pst.executeQuery();
			if(rst.next()){
		        m = new Mobile();
		        m.setMname(rst.getString("name"));
				m.setMobileid(rst.getInt("mobileid"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
			}else{
				throw new MobileException("mobile not found with id" +mid);
			} 
		}
			catch (SQLException e){
				e.printStackTrace();
				throw new MobileException("problem in fetching mobile  details"+e.getMessage());
			}
		
	
		return m;
	

}
}
