package com.cg.web.tl.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.web.tl.entities.Trainer;
import com.cg.web.tl.exception.TrainerException;
import com.cg.web.tl.service.TrainerService;





@Controller
public class TrainerController {

	@Autowired
	TrainerService service;

	public TrainerService getService() {
		return service;
	}

	public void setService(TrainerService service) {
		this.service = service;
	}
	
	@RequestMapping(value="/goToHomePage")
	public String gotoHomePage(Model m) {
		return "homePage";
	}
	

	@RequestMapping(value="/addTrainerPage")
	public String gotoaddStudentPage(Model m) {
		
		m.addAttribute("trainer",new Trainer());
		return "trainerDetailsForm";
		
	}
	
	/*@RequestMapping(value="/addTrainee")
	public String processAddEmployee(@ModelAttribute("trainer") @Valid Trainer trainer,BindingResult result,Model m) {
		System.out.println("adding ...");
			
	
	
		//return 	"trainerDetailsForm";
	
	
		int id=0;
		
		if(result.hasErrors()) {
			return "trainerDetailsForm";
		} else
			try {
				id=service.addTrainer(trainer);
				m.addAttribute("msg","Record inserted with id"+id);
				
			} catch (TrainerException e) {
				
			}
		return "trainerDetailsForm";
}*/
}

