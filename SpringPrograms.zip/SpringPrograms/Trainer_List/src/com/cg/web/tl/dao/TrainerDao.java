package com.cg.web.tl.dao;

import java.util.List;



import com.cg.web.tl.entities.Trainer;
import com.cg.web.tl.exception.TrainerException;





public interface TrainerDao {
	
public int addTrainer( Trainer trainer ) throws TrainerException;
	
	public Trainer getTrainer( int Trainee_Id ) throws TrainerException;
	
	public List<Trainer> getallDetails() throws TrainerException;
	

}
