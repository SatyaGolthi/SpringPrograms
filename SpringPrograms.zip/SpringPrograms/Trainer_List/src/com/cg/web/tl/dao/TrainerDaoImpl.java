package com.cg.web.tl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.web.tl.entities.Trainer;
import com.cg.web.tl.exception.TrainerException;

@Repository
public class TrainerDaoImpl implements TrainerDao {
	
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	@Override
	public int addTrainer(Trainer trainer) throws TrainerException {
		entityManager.persist(trainer);
		entityManager.flush();
		return trainer.getTrainee_Id();
	}

	@Override
	public Trainer getTrainer(int Trainee_Id) throws TrainerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Trainer> getallDetails() throws TrainerException {
		// TODO Auto-generated method stub
		return null;
	}

}
