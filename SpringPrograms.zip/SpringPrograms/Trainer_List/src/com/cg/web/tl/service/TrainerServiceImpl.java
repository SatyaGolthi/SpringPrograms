package com.cg.web.tl.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.tl.dao.TrainerDao;
import com.cg.web.tl.entities.Trainer;
import com.cg.web.tl.exception.TrainerException;


@Service
public class TrainerServiceImpl implements TrainerService {
	
	public TrainerDao getDao() {
		return dao;
	}

	public void setDao(TrainerDao dao) {
		this.dao = dao;
	}

	@Autowired
	TrainerDao dao;

	@Override
	public int addTrainer(Trainer trainer) throws TrainerException {
		return dao.addTrainer(trainer);
	}

	@Override
	public Trainer getTrainer(int Trainee_Id) throws TrainerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Trainer> getallDetails() throws TrainerException {
		// TODO Auto-generated method stub
		return null;
	}



}
