package com.cg.jdbc.service;

import java.util.List;

import com.cg.jdbc.dto.Employee;

public interface EmployeeService {
	
	public int getCount();
    public String getEmployeeName(int emp_id);
    public int insertRec(int emp_id,String emp_name,double emp_sal);
    public int updateRec(int emp_id,String emp_name,double emp_sal);
    public List getAll();
    public Employee getEmpBy(int emp_id);
    public List<Employee>getEmployeeList();
    
   
}
