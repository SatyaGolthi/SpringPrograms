package com.cg.jdbc.service;

import java.util.List;

import com.cg.jdbc.dao.EmployeeDao;
import com.cg.jdbc.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	
	EmployeeDao dao;

	
	public EmployeeDao getDao() {
		return dao;
	}

	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public int getCount() {
		return dao.getCount();
	}

	@Override
	public String getEmployeeName(int emp_id) {
		return dao.getEmployeeName(emp_id);
	}

	@Override
	public int insertRec(int emp_id, String emp_name, double emp_sal) {
		return dao.insertRec(emp_id, emp_name, emp_sal);
	}

	@Override
	public int updateRec(int emp_id, String emp_name, double emp_sal) {
		return dao.updateRec(emp_id, emp_name, emp_sal);
	}

	@Override
	public List getAll() {
		return dao.getAll();
	}

	@Override
	public Employee getEmpBy(int emp_id) {	
	return dao.getEmpBy(emp_id);
	}

	@Override
	public List<Employee> getEmployeeList() {	
		return dao.getAll();
	}

}
