package com.cg.jdbc.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cg.jdbc.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int getCount() {
		int count=0;
		count=jdbcTemplate.queryForObject("SELECT COUNT(*) FROM Employees",Integer.class);
		return count;
	}

	@Override
	public String getEmployeeName(int emp_id) {
		String sql="SELECT emp_name FROM Employees WHERE emp_id=?";
		String name=getJdbcTemplate().queryForObject(sql,String.class,emp_id);
		return name;
		
	}

	@Override
	public int insertRec(int emp_id, String emp_name, double emp_sal) {
		String sql="Insert into  Employees(emp_id,emp_name,emp_sal) values(?,?,?)";
		Object[] params=new Object[]{emp_id,emp_name,emp_sal};
		return getJdbcTemplate().update(sql,params);
	}

	@Override
	public int updateRec(int emp_id, String emp_name, double emp_sal) {
		String sql="update  Employees  set emp_name=?,emp_sal=? where emp_id=?";
	  Object[] params=new Object[]{emp_id,emp_name,emp_sal};
	  return getJdbcTemplate().update(sql,params);
	}

	@Override
	public List getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmpBy(int emp_id) {
		String sql="select emp_id,emp_name,emp_sal from Employees where emp_id=?";
		getJdbcTemplate().queryForObject(sql, new EmployeeRowMapper(),emp_id);
		  return null;
	}

	@Override
	public List<Employee> getEmployeeList() {
	 String sql="select * from employees where emp_sal>?";
	 List<Employee>eList=getJdbcTemplate().query(sql,new EmployeeRowMapper(),12000);
		return eList;
	}

}
