package com.cg.jdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.jdbc.dto.Employee;

public class EmployeeRowMapper implements RowMapper{
	public Object mapRow(ResultSet rs,int line)throws SQLException{
		Employee e=new Employee();
		e.setEmp_id(rs.getInt(1));
		e.setEmp_name(rs.getString(2));
		e.setEmp_sal(rs.getDouble(3));
		return e;
	}

}
