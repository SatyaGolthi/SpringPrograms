package com.cg.jdbc.client;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.cg.jdbc.dao.EmployeeDao;
import com.cg.jdbc.service.EmployeeService;



public class Client {
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("emp.xml");
		EmployeeService obj=(EmployeeService)ctx.getBean("empl");
		
		int count=obj.getCount();
		System.out.println(obj.getCount());
		try
		{
			String name=obj.getEmployeeName(1001);
		    System.out.println("Name="+name);
		}
		catch(EmptyResultDataAccessException e)
		{
			System.out.println("The Employee ID is invalid");
		}catch(DataAccessException e)
		
		
		{
			System.out.println(e.getMessage());
		}
		insert=dao.insertRec(1105,"test",555555.55);
		if(insert>0)
			System.out.println("Insert Success");
		else
			System.out.println("Insert Failed");
		
		Employee dao=serviceObj.getEmpById(1001);
		
		List<Employee> eList=service.getEmployeeList();

}
}