package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;


@WebServlet("/JDBCDemo")
public class JDBCDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(lookup="java:/OracleDS")
	DataSource ds;
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
	try{
		InitialContext ic=new InitialContext();
	//	DataSource ds=
		//		(DataSource)ic.lookup("java:/OracleDS");
		Connection conn=ds.getConnection();
		Statement st=conn.createStatement();
		String sql="SELECT empname FROM employees";
		ResultSet rst=st.executeQuery(sql);
		while(rst.next()){
			out.print("<br/>"+rst.getString(1));
		}
	}
	catch(NamingException e){
		
	e.printStackTrace();
	}
	catch(SQLException e){
		e.printStackTrace();
	}
}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
