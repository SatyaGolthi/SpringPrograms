package com.cg.springs.lab1_1;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class main {
	
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean1.xml");
		Employee obj=(Employee)ctx.getBean("empl");
		System.out.println("------Employee Details------\n"+obj);
		
	}

}
