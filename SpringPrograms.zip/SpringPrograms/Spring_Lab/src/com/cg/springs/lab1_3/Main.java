package com.cg.springs.lab1_3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springs.lab1_1.Employee;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean3.xml");
		com.cg.springs.lab1_3.SBU st=(com.cg.springs.lab1_3.SBU)ctx.getBean("SBU");
		System.out.println("------SBU Details------\n"+st);

}
}
