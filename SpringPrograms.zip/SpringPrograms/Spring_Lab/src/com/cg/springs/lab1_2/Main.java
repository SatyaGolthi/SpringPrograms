package com.cg.springs.lab1_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springs.lab1_1.Employee;

public class Main {
	
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("bean2.xml");
		com.cg.springs.lab1_2.Employee st=(com.cg.springs.lab1_2.Employee) ctx.getBean("empl");
		System.out.println("------Employee Details------\n"+st);

}
}
