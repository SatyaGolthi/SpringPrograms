
package com.cg.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.ctrl.Employee;
import com.cg.dao.IEmployeeDao;

@Service("employeeservice")
@Transactional
public class IEmployeeServiceImpl implements IEmployeeService {
    @Autowired
	IEmployeeDao employeedao;
	@Override
	public int addEmployeeData(Employee emp) {
		// TODO Auto-generated method stub
		return employeedao.addEmployeeData(emp);
		
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeedao.showAllEmployee();
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		employeedao.deleteEmployee(empId);
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee serachEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}